Project Gallery is landing page for multiple projects.
# Projects Gallery

- Six projects that demonstrate knowledge in HTML/SASS/CSS/Bootstrap. Users will have access to all lending pages and projects


- Nine JavaScript Projects. Following is the description
    - Reversi (Game)
        - A turn-based strategy game in which the computer and player will pick one move at a time. The computer creates a decision tree based on rules and recursion function calls to identify the best option. The game is set to 3 levels of the decision tree and can be set to more to increase predictability quality. Few carctirestics of the solution
            - DOM manipulation to present progress and optional move
            - Object Deep copy usage
            - Resposninvess to support mobile users  

    - Calculator (Utility)
        - functionality extended to include all bonus items
        - user can type "=" or continue with the operators key to see current result


    - ManageU (Utility) - ManageU utility allows users to trace tasks. A few areas of the solution
        - class inheritance 
        - class file export and import
        - Adding additional features to the original project 
        - pre-configure a list of items 
        - save and load data to the local machine
        - Filter using date field - "All Date", "Older than 7 days", "Older than 30 days"
        - Added all Bonus items

    - Flag (Utility)
       - Project includes API management - Fetch (await/async)
        - Extend the project to display neighboring countries and their flags.

    - Guess the number (Game) - Gussing game, technology is bootstrap and Javascript


    - My Account (Utility) - utility to manage bank transactions. User has the option to add income and expense transactions. Highlight of feaures
        - Load and Save to the local machine
        - class inheritence 
        - Seperate classes tofiles and use of Export and improt
        - Filters by 
            -income/expense/All
            -Amount type - grouping all income and deposit
            -By amount - Ascending sorting 
        - Added all Bonus items

    - Product (Utility) - All Bonus items were added (Category, grading, availability, etc.)

    - Shopping List (Utility) - Added all Bonus items

    - Store (Utility) - Functionality
        - use will select one of the areas in the image course
        - once slected, all products will be shown under the carousel
        - select/click produc will show more detail on the product


## Table of Contents
-Profolio site
-Projects Gallery
    under each projects you can find
    - Landing Page
    - Project HTML


## Installation
- Download project from gitHib
- Start index.HTML

## Usage
TBD

## Contributing
NA

## License
NA